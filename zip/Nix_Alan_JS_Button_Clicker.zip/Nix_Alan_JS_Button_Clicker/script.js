function log(element) {
    element.innerText = "logout"
}
function hide(element){
    element.style.visibility = "hidden"
}
function clickAlert(){
    alert("ninja was liked")
}
