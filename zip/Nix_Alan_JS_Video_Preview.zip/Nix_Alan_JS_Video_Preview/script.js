console.log("page loaded...");
function playv(){
    document.getElementById("water-video").play();
}
function pausev() {
    document.getElementById("water-video").pause();
}