function addLike(){
    document.getElementById("number-of-likes").innerText++
}